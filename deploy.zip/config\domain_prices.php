<?php

return [
    'com' => 6.99,
    'net' => 6.99,
    'org' => 6.99,
    'xyz' => 6.99,
    'shop' => 6.99,
    'online' => 6.99,
    'club' => 6.99,
    'pro' => 6.99,
];
