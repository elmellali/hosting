<div class="loader-wrapper">
    <div class="loader"></div>
    <div class="loader-section section-left"></div>
    <div class="loader-section section-right"></div>
</div><?php /**PATH C:\Users\1515\Downloads\elitehost-hosting-laravel-12-template-2025-09-08-13-38-08-utc\Elitehost\resources\views/elements/preloader.blade.php ENDPATH**/ ?>