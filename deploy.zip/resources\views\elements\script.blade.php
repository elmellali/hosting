    <!-- All Plugin -->
    <script defer src="{{ asset('assets/js/plugins.min.js') }}"></script>
    <!-- main js -->
    <script defer src="{{ asset('assets/js/main.js') }}"></script>