<div class="rts-breadcrumb-area body-bg-2">
    <div class="container">
        <div class="breadcrumb-inner">
            <div class="row align-items-center">
                <div class="col-lg-6 order-change">
                    <div class="breadcrumb-content">
                        <h1 class="heading-title" style="max-width: 494px;"><?php echo e($title); ?></h1>
                        <p class="desc"><?php echo e($subTitle); ?></p>
                    </div>
                </div>
                <div class="col-lg-6">
                    <div class="breadcrumb-image-area">
                        <img <?php echo $img; ?>>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="breadcrumb-shape-area">
        <img src="<?php echo e(asset('assets/images/banner/breadcrumb-shape.svg')); ?>" alt="">
    </div>
</div>
<?php /**PATH C:\Users\1515\Downloads\elitehost-hosting-laravel-12-template-2025-09-08-13-38-08-utc\Elitehost\resources\views/elements/breadcrumb.blade.php ENDPATH**/ ?>