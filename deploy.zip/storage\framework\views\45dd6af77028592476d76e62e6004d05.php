<div class="progress-wrap">
    <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 307.919;"></path>
    </svg>
</div><?php /**PATH C:\Users\1515\Downloads\elitehost-hosting-laravel-12-template-2025-09-08-13-38-08-utc\Elitehost\resources\views/elements/backtotop.blade.php ENDPATH**/ ?>