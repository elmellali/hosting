    <!-- All Plugin -->
    <script defer src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
    <!-- main js -->
    <script defer src="<?php echo e(asset('assets/js/main.js')); ?>"></script><?php /**PATH C:\Users\1515\Downloads\elitehost-hosting-laravel-12-template-2025-09-08-13-38-08-utc\Elitehost\resources\views/elements/script.blade.php ENDPATH**/ ?>