<!DOCTYPE html>
<html lang="en">

<?php echo $__env->make('elements.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<body>

    <!-- HEADER AREA -->
    <?php if(!isset($header)): ?>
        <?php echo $__env->make('elements.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <!-- HEADER AREA END -->

    <!-- Breadcrumb -->
    <?php if(!isset($breadcrumb)): ?>
        <?php echo $__env->make('elements.breadcrumb', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <!-- Breadcrumb END -->

    <?php echo $__env->yieldContent('content'); ?>

    <!-- FOOTER AREA -->
    <?php if(!isset($footer)): ?>
        <?php echo $__env->make('elements.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <!-- FOOTER AREA END -->

    <div id="anywhere-home" class="">
    </div>

    <!-- SIDE BAR AREA -->
    <?php if(!isset($sidebar)): ?>
        <?php echo $__env->make('elements.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php endif; ?>
    <!-- SIDE BAR AREA END -->

    <!-- THEME PRELOADER START -->
    <?php echo $__env->make('elements.preloader', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- THEME PRELOADER END -->




    <!-- BACK TO TOP AREA START -->
    <?php echo $__env->make('elements.backtotop', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- BACK TO TOP AREA END -->

    <?php echo $__env->make('elements.script', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

</body>

</html><?php /**PATH C:\Users\1515\Downloads\elitehost-hosting-laravel-12-template-2025-09-08-13-38-08-utc\Elitehost\resources\views/layout/layout.blade.php ENDPATH**/ ?>